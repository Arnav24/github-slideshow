#!/usr/bin/env python

from vitarana_drone.msg import *
from pid_tune.msg import PidTune
from sensor_msgs.msg import *
from std_msgs.msg import Float32
import rospy
import time
import tf
height=0
kp=0
kd=0
ki=0
roll=1500
pitch=1500
yaw=1500
def limit(value,max,min):
    if value>=max:
        return max
    elif value<=min:
        return min
    else:
        return value

def laser_pose(msg):
    global height
    height = msg.ranges[0]
def throttle(msg):
    global kp,kd,ki
    kp=msg.Kp 
    kd=msg.Kd 
    ki=msg.Ki

rospy.init_node("pose")
rospy.Subscriber('edrone/range_finder_bottom',LaserScan,laser_pose)
rospy.Subscriber('edrone/range_finder_bottom',LaserScan,laser_pose)
rospy.Subscriber('/pid_tuning_altitude',PidTune,throttle)




zpub=rospy.Publisher('z_error',Float32,queue_size=1)
zero=rospy.Publisher('Arnav',Float32,queue_size=1)
cmd_pub = rospy.Publisher('/drone_command',edrone_cmd ,queue_size=1)
cmd=edrone_cmd()

error_h=0
error_old=0
error_change=0
error_total=0
while not rospy.is_shutdown():
    error_h= 3- height #throttle
    error_change = error_h - error_old
    error_total = 34*error_h*0.06 + 358*error_change
    error_old = error_h
    cmd.rcThrottle=limit((1495 + error_total),1800,1200)
    
    zero.publish(0)
    zpub.publish(error_h)
    cmd_pub.publish(cmd)