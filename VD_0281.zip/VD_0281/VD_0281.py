#!/usr/bin/env python

import rospy

from geometry_msgs.msg import Twist

from turtlesim.msg import Pose

import sys

def pose_callback(msg):
    pose=msg.theta


def move_turtle():
#starts a new node
    rospy.init_node('node_turtle_revolve',anonymous=True)
    velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    vel_msg = Twist()
#predefined values for input
    speed=36
    angle=360
    #converting from angles to radian
    angular_speed=speed*2*3.14/360
    radian_angle=angle*2*3.14/360

    vel_msg.linear.x=1    #radius of the circular path is 1
    vel_msg.linear.y=0	
    vel_msg.linear.z=0
    vel_msg.angular.x=0
    vel_msg.angular.y=0
    vel_msg.angular.z=abs(angular_speed)
#setting the current time for distance calculus
    t0=rospy.Time.now().to_sec()
    current_angle=0
# loop for the turtle to stop at the initial position
    while(current_angle<=radian_angle+0.18):
        velocity_publisher.publish(vel_msg)
#takes actual time to velocity calculus
        t1 = rospy.Time.now().to_sec()
#Calculates distancePoseStamped
        current_angle = angular_speed*(t1-t0)
# for printing the angular position of the turtle
	rospy.loginfo("moving in circle:/n"+str(current_angle))
	rospy.Subscriber("/turtle1/pose", Pose, pose_callback)
#after the loop stops the turtle.
    vel_msg.angular.z = 0
    vel_msg.linear.x=0
    velocity_publisher.publish(vel_msg)
    rospy.spin() 

if __name__ == '__main__':
    try:
#testing our function
        move_turtle()
    except rospy.ROSInterruptException:
        pass
